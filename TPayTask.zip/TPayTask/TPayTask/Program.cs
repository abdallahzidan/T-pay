﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TPayTask

{
    /// <summary>
    /// Program outputs different ways to calculate the last number from the first list.
    /// the beta algorithm applying the concept of recursion 
    /// </summary>
    class Program
    {

        static void Main(string[] args)
        {
            print(ReadInput());
        }

        /// <summary>
        /// gets an input from user.
        /// </summary>
        /// <returns> numbers list </returns>
        private static List<int> ReadInput()
        {
            Console.WriteLine(" Program outputs different ways to calculate the last number from the first list ");
            Console.WriteLine(" Please keep enter your list numbers , Enter 0 when you finish ");
            List<int> inputList = new List<int>();

            string Number = Console.ReadLine();
            int value;

            while (Number != "0" && int.TryParse(Number, out value))
            {

                if (inputList.Contains(value))
                {
                    Console.Write("this number already exsist , please enter another one : \n");
                }
                else
                {
                    inputList.Add(value);
                }
                Number = Console.ReadLine();
            }
            if (Number == "0")
            {
                Console.WriteLine(" Your List is : ");
                Console.Write(" { ");
                for (int i = 0; i < inputList.Count; i++)
                {
                    if (i == inputList.Count - 1) { Console.Write(inputList.ElementAt(i)); } else { Console.Write(inputList.ElementAt(i) + ","); }
                }
                Console.Write(" } \n");
                Console.WriteLine("Please enter your target number: \n");
                string target = Console.ReadLine();
                int targetValue;
                if (int.TryParse(target, out targetValue))
                {
                    inputList.Add(targetValue);
                }
                else
                {
                    Console.Write("The value must be of integer type, try again later . . .  ");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.Write("The value must be of integer type, try again later . . .  ");
                Console.ReadLine();
            }
            return inputList;
        }


        /// <summary>
        /// Prints all possible calculations that out put the target number.
        /// </summary>
        /// <param name="input"> input list</param>
        private static void print(List<int> input)
        {
            int target = input.ElementAt(input.Count - 1);
            List<int> myList = input.GetRange(0, input.Count - 1);
            List<int> reserved = new List<int>();
            BiList output = GetCalculations(myList, target);
            for (int i = 0; i < output.first.Count; i++)
            {
                string sec = (output.second.ElementAt(i) > 0) ? "+" + output.second.ElementAt(i).ToString() : output.second.ElementAt(i).ToString();
                System.Console.WriteLine(output.first.ElementAt(i).ToString() + sec);

            }
            for (int l = 0; l < output.first.Count; l++)
            {
                if (!reserved.Contains(output.first.ElementAt(l)))
                {
                    reserved.Add(output.first.ElementAt(l));
                    List<int> passed = myList;
                    passed.Remove(output.second.ElementAt(l));
                    BiList outfirst = GetCalculations(passed, output.first.ElementAt(l));
                    for (int f = 0; f < outfirst.first.Count; f++)
                    {
                        if (!(outfirst.first.ElementAt(f) == outfirst.second.ElementAt(f)))
                        {
                            System.Console.Write("(");
                            System.Console.Write(outfirst.first.ElementAt(f));
                            if (outfirst.second.ElementAt(f) > 0) { System.Console.Write("+" + outfirst.second.ElementAt(f)); } else { System.Console.Write(outfirst.second.ElementAt(f)); }
                            System.Console.Write(")");
                            if (output.second.ElementAt(l) > 0) { System.Console.Write("+" + output.second.ElementAt(l)); } else { System.Console.Write(output.second.ElementAt(l)); }
                            System.Console.WriteLine(" ");
                        }

                    }
                }
                if (!reserved.Contains(output.second.ElementAt(l)))
                {
                    reserved.Add(output.second.ElementAt(l));
                    List<int> passed = myList;
                    passed.Remove(output.first.ElementAt(l));
                    BiList outputsecond = GetCalculations(passed, output.second.ElementAt(l));
                    for (int s = 0; s < outputsecond.first.Count; s++)
                    {
                        if (!(outputsecond.first.ElementAt(s) == outputsecond.second.ElementAt(s)))
                        {
                            System.Console.Write(output.first.ElementAt(l));
                            if (output.second.ElementAt(l) > 0)
                            {
                                System.Console.Write("+");
                            }
                            else
                            {
                                System.Console.Write("-");
                            }
                            System.Console.Write("(");
                            System.Console.Write(outputsecond.first.ElementAt(s));
                            if (outputsecond.second.ElementAt(s) > 0) { System.Console.Write("+" + outputsecond.second.ElementAt(s)); } else { System.Console.Write(outputsecond.second.ElementAt(s)); }
                            System.Console.Write(")");
                            System.Console.WriteLine(" ");
                        }

                    }
                }



            }

            System.Console.WriteLine("press Enter to exit");

            System.Console.ReadLine();

        }

        /// <summary>
        /// function implements algorithm for getting calculations 
        /// </summary>
        /// <param name="list">input list</param>
        /// <param name="num"> target number</param>
        /// <returns></returns>
        private static BiList GetCalculations(List<int> list, int num)
        {
            BiList output = new BiList();
            output.first = new List<int>();
            output.second = new List<int>();
            for (int i = 0; i < list.Count; i++)
            {
                if (list.ElementAt(i) < num)
                {
                    int temp = num - list.ElementAt(i);
                    if (list.Contains(temp) && temp != num)
                    {
                        output.first.Add(list.ElementAt(i));
                        output.second.Add(temp);
                    }
                }
                else
                {
                    int temp = list.ElementAt(i) - num;
                    if (list.Contains(temp) && temp != num)
                    {
                        output.first.Add(list.ElementAt(i));
                        output.second.Add(-temp);
                    }
                }
            }
            return output;
        }

    }
    public class BiList
    {
        public List<int> first { get; set; }
        public List<int> second { get; set; }
    }
}
